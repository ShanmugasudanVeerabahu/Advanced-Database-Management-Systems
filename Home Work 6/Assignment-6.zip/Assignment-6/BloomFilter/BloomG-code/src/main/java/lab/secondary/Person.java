package lab.secondary;

public class Person {
	final int id;
	final String firstName;
	final String lastName;
	final int birthYear;

	Person(final int id, String firstName, String lastName, int birthYear) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthYear = birthYear;
	}
}
